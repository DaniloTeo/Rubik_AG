/*
	Danilo da Costa Telles Teo	9293626	danilo.teo@usp.br
	Leonardo de Souza Lemes		8941126	leonardo.lemes@usp.br
	Rodrigo Valim Maciel		9278149	rodrigo.valim.maciel@usp.br
*/

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <ctime>

/*
	IMPORTANTE

	para evitar problemas de perspectiva e orientacao do cubo, considere como padroes: 

	FACE	COR
	top		white
	down	yellow
	front	green
	back	blue
	left	orange
	right	red

	ou seja, ao segurar o cubo, a face superior deve ser a de centro branco, a face frontal 
	deve ser a de centro verde, a face inferior deve ser a de centro amarelo... de acordo com os 
	enums do codigo

	ha 18 movimentos possiveis no cubo 3x3, sao 6 movimentos para cada eixo, sendo 3 movimentos horarios e 3 movimentos 
	anti horarios

	imagine o cubo resolvido (ou tenha um, fica mais facil), coloque o cubo a sua ESQUERDA, um pouco abaixo dos seus olhos, voce deve conseguir enxergar 3 faces,
	a face superior(branca), a face frontal (verde) e a face lateral direita (vermelha), no cubo ha 3 eixos, chamaremos de eixo X, Y e Z

	ha 3 fatores que definem um movimento, seu eixo, sua camada e sua orientacao

	o eixo x liga a face laranja a face vermelha - left>right
	o eixo y liga a face azul a face verde - back>front
	o eixo z liga a face amarelo a face branca - down>top

	para cada eixo, temos a camada 1, 2 e 3, sempre comece a contar do 1 pela camada da esquerda da definicao das ligacoes dos eixos
	ou seja, Y3 indica um movimento na face frontal do cubo
	X1 indica um movimento na face lateral esquerda
	X3 indica um movimento na face lateral direita

	temos tambem a orientacao, que esta definida como
	+ sentido horario
	- sentido anti horario

	lembrando que e importante que o cubo esteja na posicao mencionada e voce esteja vendo as 3 faces mencionadas

	o sentido horario e definido com base na SUA perspectiva atual do cubo, ou seja
	X3+ vai rodar a face lateral direita no sentido horario, colocando 3 pecas verdes no topo
	Z2- vai rodar o meio do cubo na horizontal no seentido anti horario, de modo que a face frontal tenha no meio 3 pecas laranjas
	Y1+ vai rodar a face traseira do cubo no sentido horario, deixando o topo com 3 pecas laranjas
*/

/*
	para compilar: g++ main.cpp -o main -O3 -march=native
	para rodar: ./main < input.txt > output.txt

	ele vai dar um warning de nao usar o valor de retorno do scanf, mas isso nao da nada

	na mesma pasta do executavel deve haver um arquivo chamado input.txt contendo o cubo 
	de entrada do algoritmo, o programa ira criar um arquivo chamado output.txt contendo a 
	saida do programa

	o arquivo de entrada deve ser a descricao de cada uma das faces do cubo na seguinte ordem: 
	TOP, DOWN, FRONT, BACK, LEFT, RIGHT

	W - white
	Y - yellow
	G - green
	B - blue
	O - orange
	R - red

	exemplo:

	O R R
	G W W
	Y O O

	Y R Y
	Y Y R
	G O O

	O Y G
	G G W
	B G G

	W W W
	B B B
	B G W

	B Y G
	Y O W
	R R R

	W O B
	B R O
	R B Y
*/

/*
	no nosso algoritmo genetico, voce podera notar que nao ha crossover, como estamos tratando de resolver cubo magico, o cromossomo representa uma lista de movimentos
	cada movimento e EXTREMAMENTE dependente dos movimentos que vem antes dele, nao faz muito sentido pegar duas listas de movimentos que sao MUITO boas e quase resolvem um cubo
	e cruzar, porque o resultado vai ser uma lista horrivel, isto e, mesmo que voce pegue um pai e uma mae com fitness alto, o filho vai ter o fitness muito baixo porque nao ha uma boa
	maneira de combinar os dois cromossomos
	entao, implementamos uma reproducao assexuada, como em simples bacterias, ocorre a replicacao e uma leve mutacao
*/

using namespace std;

// parametros de execucao
const int POPULATION_SIZE = 100000; // tamanho da populacao
const int MAX_GENERATIONS = 1000; // quantidade de geracoes
const int GENOCIDE_GENS = MAX_GENERATIONS / 4; // acontecerao 3 genocidios
const int PREDATION_GENS = MAX_GENERATIONS / 10; // acontecerao 9 predacoes
const double ELITISM_RATE = 0.5; // taxa de elitismo, os top 50% de cada populacao serao passados adiante
const double PREDATION_RATE = 0.2; // taxa de predacao, os bottom 20% da populacao serao eliminados quando ocorrer a predacao
const int CHROMOSOME_SIZE = 25; // tamanho do cromossomo - 25 movimentos, VALE LEMBRAR QUE O TAMANHO FINAL DA LISTA DE MOVIMENTO E 25*4, ou seja, tamanho do cromossomo * (quantidade de genocidios + 1)

enum {
	TOP,
	DOWN,
	FRONT,
	BACK,
	LEFT,
	RIGHT
};

enum {
	WHITE,
	YELLOW,
	GREEN,
	BLUE,
	ORANGE,
	RED
};

// essa struct representa um individuo da nossa populacao, um individuo e um cubo, com seu cromossomo contendo os movimentos necessarios para ir do cubo de entrada ate seu estado atual
// e o seu valor de fitness
struct Individual {
	int state[6][3][3]; // estado atual do cubo, 6 matrizes 3x3, representando cada face do cubo
	int chromosome[CHROMOSOME_SIZE]; // cromossomo do cubo, ou seja, um lista de movimentos
	int fitness; // valor de fitness do individuo
} origin; // declara um individuo especial, o cubo de origem, ou seja, o cubo de entrada

/*
	estamos utilizando genocidios, a cada genocidio, pegamos o melhor individuo da populacao e aplicamos o algoritmo novamente nesse individuo, ou seja, ele se torna o cubo de entrada, o origin
	por isso salvamos os seus movimentos na variavel all_moves, pois ao final dos genocidios, teremos a lista completa de movimentos

	isso e tipo moer cana, voce termina de moer a cada, dobra ela e moe de novo, e basicamente isso que fazemos com cada genocidio, pegamos o melhor resultado e aplicamos o algoritmo nele de novo
*/
vector<int> all_moves;

// funcao de comparacao para poder ordenar pelo fitness
bool cmp(const Individual& a, const Individual& b) {
	return a.fitness > b.fitness;
}

// exibe o estado atual do cubo e seu valor de fitness
void print_individal(Individual x) {
	for (int i = 0; i < 6; i++) {
		switch (i) {
			case TOP:
				printf("TOP\n");
				break;
			case DOWN:
				printf("DOWN\n");
				break;
			case FRONT:
				printf("FRONT\n");
				break;
			case BACK:
				printf("BACK\n");
				break;
			case LEFT:
				printf("LEFT\n");
				break;
			case RIGHT:
				printf("RIGHT\n");
				break;
		}
		for (int j = 0; j < 3; j++) {
			for (int k = 0; k < 3; k++) {
				switch (x.state[i][j][k]) {
					case WHITE:
						printf("W ");
						break;
					case YELLOW:
						printf("Y ");
						break;
					case BLUE:
						printf("B ");
						break;
					case GREEN:
						printf("G ");
						break;
					case RED:
						printf("R ");
						break;
					case ORANGE:
						printf("O ");
						break;
				}
			}
			printf("\n");
		}
		printf("\n");
	}

	printf("fitness: %d\n\n", x.fitness);
}

// exibe a lista de movimentos
void print_moves(vector<int> moves) {
	for (int i = 0; i < moves.size(); i++) {
		switch(moves[i]) {
			case 0:
				printf("X1+ ");
				break;
			case 1:
				printf("X1- ");
				break;
			case 2:
				printf("X2+ ");
				break;
			case 3:
				printf("X2- ");
				break;
			case 4:
				printf("X3+ ");
				break;
			case 5:
				printf("X3- ");
				break;
			case 6:
				printf("Y1+ ");
				break;
			case 7:
				printf("Y1- ");
				break;
			case 8:
				printf("Y2+ ");
				break;
			case 9:
				printf("Y2- ");
				break;
			case 10:
				printf("Y3+ ");
				break;
			case 11:
				printf("Y3- ");
				break;
			case 12:
				printf("Z1+ ");
				break;
			case 13:
				printf("Z1- ");
				break;
			case 14:
				printf("Z2+ ");
				break;
			case 15:
				printf("Z2- ");
				break;
			case 16:
				printf("Z3+ ");
				break;
			case 17:
				printf("Z3- ");
				break;
		}
	}
	printf("\n\n");
}

// realiza uma rotacao no cubo
// int face - face a ser rodada
// char ort - horaria ou anti horaria
void rotate(Individual& x, int face, char ort) {
	int tmp[3][3];

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			tmp[i][j] = x.state[face][j][i];
		}
	}

	switch (ort) {
		case '+':
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					x.state[face][i][2 - j] = tmp[i][j];
				}
			}
			break;
		case '-':
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					x.state[face][2 - i][j] = tmp[i][j];
				}
			}
			break;
	}
}

// realiza o movimento no cubo
// int move - movimento a ser realizado
void move(Individual& x, int move) {
	int tmp1, tmp2, tmp3;
	switch (move) {
		case 0:
			// X1+
			rotate(x, LEFT, '-');

			tmp1 = x.state[TOP][0][0];
			tmp2 = x.state[TOP][1][0];
			tmp3 = x.state[TOP][2][0];

			x.state[TOP][0][0] = x.state[FRONT][0][0];
			x.state[TOP][1][0] = x.state[FRONT][1][0];
			x.state[TOP][2][0] = x.state[FRONT][2][0];

			x.state[FRONT][0][0] = x.state[DOWN][0][0];
			x.state[FRONT][1][0] = x.state[DOWN][1][0];
			x.state[FRONT][2][0] = x.state[DOWN][2][0];

			x.state[DOWN][0][0] = x.state[BACK][2][2];
			x.state[DOWN][1][0] = x.state[BACK][1][2];
			x.state[DOWN][2][0] = x.state[BACK][0][2];

			x.state[BACK][2][2] = tmp1;
			x.state[BACK][1][2] = tmp2;
			x.state[BACK][0][2] = tmp3;
			break;
		case 1:
			// X1-
			rotate(x, LEFT, '+');

			tmp1 = x.state[TOP][0][0];
			tmp2 = x.state[TOP][1][0];
			tmp3 = x.state[TOP][2][0];

			x.state[TOP][0][0] = x.state[BACK][2][2];
			x.state[TOP][1][0] = x.state[BACK][1][2];
			x.state[TOP][2][0] = x.state[BACK][0][2];

			x.state[BACK][2][2] = x.state[DOWN][0][0];
			x.state[BACK][1][2] = x.state[DOWN][1][0];
			x.state[BACK][0][2] = x.state[DOWN][2][0];

			x.state[DOWN][0][0] = x.state[FRONT][0][0];
			x.state[DOWN][1][0] = x.state[FRONT][1][0];
			x.state[DOWN][2][0] = x.state[FRONT][2][0];

			x.state[FRONT][0][0] = tmp1;
			x.state[FRONT][1][0] = tmp2;
			x.state[FRONT][2][0] = tmp3;
			break;
		case 2:
			// X2+
			tmp1 = x.state[TOP][0][1];
			tmp2 = x.state[TOP][1][1];
			tmp3 = x.state[TOP][2][1];

			x.state[TOP][0][1] = x.state[FRONT][0][1];
			x.state[TOP][1][1] = x.state[FRONT][1][1];
			x.state[TOP][2][1] = x.state[FRONT][2][1];

			x.state[FRONT][0][1] = x.state[DOWN][0][1];
			x.state[FRONT][1][1] = x.state[DOWN][1][1];
			x.state[FRONT][2][1] = x.state[DOWN][2][1];

			x.state[DOWN][0][1] = x.state[BACK][2][1];
			x.state[DOWN][1][1] = x.state[BACK][1][1];
			x.state[DOWN][2][1] = x.state[BACK][0][1];

			x.state[BACK][2][1] = tmp1;
			x.state[BACK][1][1] = tmp2;
			x.state[BACK][0][1] = tmp3;
			break;
		case 3:
			// X2-
			tmp1 = x.state[TOP][0][1];
			tmp2 = x.state[TOP][1][1];
			tmp3 = x.state[TOP][2][1];

			x.state[TOP][0][1] = x.state[BACK][2][1];
			x.state[TOP][1][1] = x.state[BACK][1][1];
			x.state[TOP][2][1] = x.state[BACK][0][1];

			x.state[BACK][2][1] = x.state[DOWN][0][1];
			x.state[BACK][1][1] = x.state[DOWN][1][1];
			x.state[BACK][0][1] = x.state[DOWN][2][1];

			x.state[DOWN][0][1] = x.state[FRONT][0][1];
			x.state[DOWN][1][1] = x.state[FRONT][1][1];
			x.state[DOWN][2][1] = x.state[FRONT][2][1];

			x.state[FRONT][0][1] = tmp1;
			x.state[FRONT][1][1] = tmp2;
			x.state[FRONT][2][1] = tmp3;
			break;
		case 4:
			// X3+
			rotate(x, RIGHT, '+');

			tmp1 = x.state[TOP][0][2];
			tmp2 = x.state[TOP][1][2];
			tmp3 = x.state[TOP][2][2];

			x.state[TOP][0][2] = x.state[FRONT][0][2];
			x.state[TOP][1][2] = x.state[FRONT][1][2];
			x.state[TOP][2][2] = x.state[FRONT][2][2];

			x.state[FRONT][0][2] = x.state[DOWN][0][2];
			x.state[FRONT][1][2] = x.state[DOWN][1][2];
			x.state[FRONT][2][2] = x.state[DOWN][2][2];

			x.state[DOWN][0][2] = x.state[BACK][2][0];
			x.state[DOWN][1][2] = x.state[BACK][1][0];
			x.state[DOWN][2][2] = x.state[BACK][0][0];

			x.state[BACK][2][0] = tmp1;
			x.state[BACK][1][0] = tmp2;
			x.state[BACK][0][0] = tmp3;
			break;
		case 5:
			// X3-
			rotate(x, RIGHT, '-');

			tmp1 = x.state[TOP][0][2];
			tmp2 = x.state[TOP][1][2];
			tmp3 = x.state[TOP][2][2];

			x.state[TOP][0][2] = x.state[BACK][2][0];
			x.state[TOP][1][2] = x.state[BACK][1][0];
			x.state[TOP][2][2] = x.state[BACK][0][0];

			x.state[BACK][2][0] = x.state[DOWN][0][2];
			x.state[BACK][1][0] = x.state[DOWN][1][2];
			x.state[BACK][0][0] = x.state[DOWN][2][2];

			x.state[DOWN][0][2] = x.state[FRONT][0][2];
			x.state[DOWN][1][2] = x.state[FRONT][1][2];
			x.state[DOWN][2][2] = x.state[FRONT][2][2];

			x.state[FRONT][0][2] = tmp1;
			x.state[FRONT][1][2] = tmp2;
			x.state[FRONT][2][2] = tmp3;
			break;
		case 6:
			// Y1+
			rotate(x, BACK, '-');

			tmp1 = x.state[TOP][0][0];
			tmp2 = x.state[TOP][0][1];
			tmp3 = x.state[TOP][0][2];

			x.state[TOP][0][0] = x.state[LEFT][2][0];
			x.state[TOP][0][1] = x.state[LEFT][1][0];
			x.state[TOP][0][2] = x.state[LEFT][0][0];

			x.state[LEFT][2][0] = x.state[DOWN][2][2];
			x.state[LEFT][1][0] = x.state[DOWN][2][1];
			x.state[LEFT][0][0] = x.state[DOWN][2][0];

			x.state[DOWN][2][2] = x.state[RIGHT][0][2];
			x.state[DOWN][2][1] = x.state[RIGHT][1][2];
			x.state[DOWN][2][0] = x.state[RIGHT][2][2];

			x.state[RIGHT][0][2] = tmp1;
			x.state[RIGHT][1][2] = tmp2;
			x.state[RIGHT][2][2] = tmp3;
			break;
		case 7:
			// Y1-
			rotate(x, BACK, '+');

			tmp1 = x.state[TOP][0][0];
			tmp2 = x.state[TOP][0][1];
			tmp3 = x.state[TOP][0][2];

			x.state[TOP][0][0] = x.state[RIGHT][0][2];
			x.state[TOP][0][1] = x.state[RIGHT][1][2];
			x.state[TOP][0][2] = x.state[RIGHT][2][2];

			x.state[RIGHT][0][2] = x.state[DOWN][2][2];
			x.state[RIGHT][1][2] = x.state[DOWN][2][1];
			x.state[RIGHT][2][2] = x.state[DOWN][2][0];

			x.state[DOWN][2][2] = x.state[LEFT][2][0];
			x.state[DOWN][2][1] = x.state[LEFT][1][0];
			x.state[DOWN][2][0] = x.state[LEFT][0][0];

			x.state[LEFT][2][0] = tmp1;
			x.state[LEFT][1][0] = tmp2;
			x.state[LEFT][0][0] = tmp3;
			break;
		case 8:
			// Y2+
			tmp1 = x.state[TOP][1][0];
			tmp2 = x.state[TOP][1][1];
			tmp3 = x.state[TOP][1][2];

			x.state[TOP][1][0] = x.state[LEFT][2][1];
			x.state[TOP][1][1] = x.state[LEFT][1][1];
			x.state[TOP][1][2] = x.state[LEFT][0][1];

			x.state[LEFT][2][1] = x.state[DOWN][1][2];
			x.state[LEFT][1][1] = x.state[DOWN][1][1];
			x.state[LEFT][0][1] = x.state[DOWN][1][0];

			x.state[DOWN][1][2] = x.state[RIGHT][0][1];
			x.state[DOWN][1][1] = x.state[RIGHT][1][1];
			x.state[DOWN][1][0] = x.state[RIGHT][2][1];

			x.state[RIGHT][0][1] = tmp1;
			x.state[RIGHT][1][1] = tmp2;
			x.state[RIGHT][2][1] = tmp3;
			break;
		case 9:
			// Y2-
			tmp1 = x.state[TOP][1][0];
			tmp2 = x.state[TOP][1][1];
			tmp3 = x.state[TOP][1][2];

			x.state[TOP][1][0] = x.state[RIGHT][0][1];
			x.state[TOP][1][1] = x.state[RIGHT][1][1];
			x.state[TOP][1][2] = x.state[RIGHT][2][1];

			x.state[RIGHT][0][1] = x.state[DOWN][1][2];
			x.state[RIGHT][1][1] = x.state[DOWN][1][1];
			x.state[RIGHT][2][1] = x.state[DOWN][1][0];

			x.state[DOWN][1][2] = x.state[LEFT][2][1];
			x.state[DOWN][1][1] = x.state[LEFT][1][1];
			x.state[DOWN][1][0] = x.state[LEFT][0][1];

			x.state[LEFT][2][1] = tmp1;
			x.state[LEFT][1][1] = tmp2;
			x.state[LEFT][0][1] = tmp3;
			break;
		case 10:
			// Y3+
			rotate(x, FRONT, '+');

			tmp1 = x.state[TOP][2][0];
			tmp2 = x.state[TOP][2][1];
			tmp3 = x.state[TOP][2][2];

			x.state[TOP][2][0] = x.state[LEFT][2][2];
			x.state[TOP][2][1] = x.state[LEFT][1][2];
			x.state[TOP][2][2] = x.state[LEFT][0][2];

			x.state[LEFT][2][2] = x.state[DOWN][0][2];
			x.state[LEFT][1][2] = x.state[DOWN][0][1];
			x.state[LEFT][0][2] = x.state[DOWN][0][0];

			x.state[DOWN][0][2] = x.state[RIGHT][0][0];
			x.state[DOWN][0][1] = x.state[RIGHT][1][0];
			x.state[DOWN][0][0] = x.state[RIGHT][2][0];

			x.state[RIGHT][0][0] = tmp1;
			x.state[RIGHT][1][0] = tmp2;
			x.state[RIGHT][2][0] = tmp3;
			break;
		case 11:
			// Y3-
			rotate(x, FRONT, '-');

			tmp1 = x.state[TOP][2][0];
			tmp2 = x.state[TOP][2][1];
			tmp3 = x.state[TOP][2][2];

			x.state[TOP][2][0] = x.state[RIGHT][0][0];
			x.state[TOP][2][1] = x.state[RIGHT][1][0];
			x.state[TOP][2][2] = x.state[RIGHT][2][0];

			x.state[RIGHT][0][0] = x.state[DOWN][0][2];
			x.state[RIGHT][1][0] = x.state[DOWN][0][1];
			x.state[RIGHT][2][0] = x.state[DOWN][0][0];

			x.state[DOWN][0][2] = x.state[LEFT][2][2];
			x.state[DOWN][0][1] = x.state[LEFT][1][2];
			x.state[DOWN][0][0] = x.state[LEFT][0][2];

			x.state[LEFT][2][2] = tmp1;
			x.state[LEFT][1][2] = tmp2;
			x.state[LEFT][0][2] = tmp3;
			break;
		case 12:
			// Z1+
			rotate(x, DOWN, '-');

			tmp1 = x.state[FRONT][2][0];
			tmp2 = x.state[FRONT][2][1];
			tmp3 = x.state[FRONT][2][2];

			x.state[FRONT][2][0] = x.state[RIGHT][2][0];
			x.state[FRONT][2][1] = x.state[RIGHT][2][1];
			x.state[FRONT][2][2] = x.state[RIGHT][2][2];

			x.state[RIGHT][2][0] = x.state[BACK][2][0];
			x.state[RIGHT][2][1] = x.state[BACK][2][1];
			x.state[RIGHT][2][2] = x.state[BACK][2][2];

			x.state[BACK][2][0] = x.state[LEFT][2][0];
			x.state[BACK][2][1] = x.state[LEFT][2][1];
			x.state[BACK][2][2] = x.state[LEFT][2][2];

			x.state[LEFT][2][0] = tmp1;
			x.state[LEFT][2][1] = tmp2;
			x.state[LEFT][2][2] = tmp3;
			break;
		case 13:
			// Z1-
			rotate(x, DOWN, '+');

			tmp1 = x.state[FRONT][2][0];
			tmp2 = x.state[FRONT][2][1];
			tmp3 = x.state[FRONT][2][2];

			x.state[FRONT][2][0] = x.state[LEFT][2][0];
			x.state[FRONT][2][1] = x.state[LEFT][2][1];
			x.state[FRONT][2][2] = x.state[LEFT][2][2];

			x.state[LEFT][2][0] = x.state[BACK][2][0];
			x.state[LEFT][2][1] = x.state[BACK][2][1];
			x.state[LEFT][2][2] = x.state[BACK][2][2];

			x.state[BACK][2][0] = x.state[RIGHT][2][0];
			x.state[BACK][2][1] = x.state[RIGHT][2][1];
			x.state[BACK][2][2] = x.state[RIGHT][2][2];

			x.state[RIGHT][2][0] = tmp1;
			x.state[RIGHT][2][1] = tmp2;
			x.state[RIGHT][2][2] = tmp3;
			break;
		case 14:
			// Z2+
			tmp1 = x.state[FRONT][1][0];
			tmp2 = x.state[FRONT][1][1];
			tmp3 = x.state[FRONT][1][2];

			x.state[FRONT][1][0] = x.state[RIGHT][1][0];
			x.state[FRONT][1][1] = x.state[RIGHT][1][1];
			x.state[FRONT][1][2] = x.state[RIGHT][1][2];

			x.state[RIGHT][1][0] = x.state[BACK][1][0];
			x.state[RIGHT][1][1] = x.state[BACK][1][1];
			x.state[RIGHT][1][2] = x.state[BACK][1][2];

			x.state[BACK][1][0] = x.state[LEFT][1][0];
			x.state[BACK][1][1] = x.state[LEFT][1][1];
			x.state[BACK][1][2] = x.state[LEFT][1][2];

			x.state[LEFT][1][0] = tmp1;
			x.state[LEFT][1][1] = tmp2;
			x.state[LEFT][1][2] = tmp3;
			break;
		case 15:
			// Z2-
			tmp1 = x.state[FRONT][1][0];
			tmp2 = x.state[FRONT][1][1];
			tmp3 = x.state[FRONT][1][2];

			x.state[FRONT][1][0] = x.state[LEFT][1][0];
			x.state[FRONT][1][1] = x.state[LEFT][1][1];
			x.state[FRONT][1][2] = x.state[LEFT][1][2];

			x.state[LEFT][1][0] = x.state[BACK][1][0];
			x.state[LEFT][1][1] = x.state[BACK][1][1];
			x.state[LEFT][1][2] = x.state[BACK][1][2];

			x.state[BACK][1][0] = x.state[RIGHT][1][0];
			x.state[BACK][1][1] = x.state[RIGHT][1][1];
			x.state[BACK][1][2] = x.state[RIGHT][1][2];

			x.state[RIGHT][1][0] = tmp1;
			x.state[RIGHT][1][1] = tmp2;
			x.state[RIGHT][1][2] = tmp3;
			break;
		case 16:
			// Z3+
			rotate(x, TOP, '+');

			tmp1 = x.state[FRONT][0][0];
			tmp2 = x.state[FRONT][0][1];
			tmp3 = x.state[FRONT][0][2];

			x.state[FRONT][0][0] = x.state[RIGHT][0][0];
			x.state[FRONT][0][1] = x.state[RIGHT][0][1];
			x.state[FRONT][0][2] = x.state[RIGHT][0][2];

			x.state[RIGHT][0][0] = x.state[BACK][0][0];
			x.state[RIGHT][0][1] = x.state[BACK][0][1];
			x.state[RIGHT][0][2] = x.state[BACK][0][2];

			x.state[BACK][0][0] = x.state[LEFT][0][0];
			x.state[BACK][0][1] = x.state[LEFT][0][1];
			x.state[BACK][0][2] = x.state[LEFT][0][2];

			x.state[LEFT][0][0] = tmp1;
			x.state[LEFT][0][1] = tmp2;
			x.state[LEFT][0][2] = tmp3;
			break;
		case 17:
			// Z3-
			rotate(x, TOP, '-');

			tmp1 = x.state[FRONT][0][0];
			tmp2 = x.state[FRONT][0][1];
			tmp3 = x.state[FRONT][0][2];

			x.state[FRONT][0][0] = x.state[LEFT][0][0];
			x.state[FRONT][0][1] = x.state[LEFT][0][1];
			x.state[FRONT][0][2] = x.state[LEFT][0][2];

			x.state[LEFT][0][0] = x.state[BACK][0][0];
			x.state[LEFT][0][1] = x.state[BACK][0][1];
			x.state[LEFT][0][2] = x.state[BACK][0][2];

			x.state[BACK][0][0] = x.state[RIGHT][0][0];
			x.state[BACK][0][1] = x.state[RIGHT][0][1];
			x.state[BACK][0][2] = x.state[RIGHT][0][2];

			x.state[RIGHT][0][0] = tmp1;
			x.state[RIGHT][0][1] = tmp2;
			x.state[RIGHT][0][2] = tmp3;
			break;
	}
}

// calcula o valor de fitness de um individuo, o nosso fitness e calculado como a quantidade de cubinhos com as cores corretas na sua face
// para cada face temos um valor de fitness de 0 a 8, lembrando que a peca central SEMPRE esta certa
// como temos 6 faces, nosso fitness vai de 0 a 48, sendo 48 o cubo completo
void calculate_fitness(Individual &x) {
	int fitness = 0;

	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 3; j++) {
			for (int k = 0; k < 3; k++) {
				if (j != 1 || k != 1) { // nao checa a peca do meio, o cubinho [1][1]
					if (x.state[i][j][k] == x.state[i][1][1]) { // compara as pecas das pontas com a peca do meio
						fitness++;
					}
				}
			}
		}
	}

	x.fitness = fitness;
}

// aplica os movimentos contidos no cromossomo de um individuo no cubo desse individuo, essa funcao deve ser chamada antes de calcular o fitness
void apply_movements(Individual& x) {
	for (int i = 0; i < CHROMOSOME_SIZE; i++) {
		move(x, x.chromosome[i]);
	}
}

// exibe o maximo e a media dos fitness da populacao
void print_population_info(vector<Individual> population) {
	int max = population[0].fitness; // estamos ordenando pelo fitness, entao e so pegar o primeiro
	double avg = 0.0;

	for (int i = 0; i < population.size(); i++) {
		avg += population[i].fitness;
	}
	avg /= population.size();

	printf("Maximum fitness: %d\n", max);
	printf("Average fitness: %.2lf\n\n", avg);
}

// realiza uma mutacao no individuo x, alterando um movimento aleatorio do seu cromossomo para outro movimento aleatorio
void mutate(Individual& x) {
	int idx = rand() % CHROMOSOME_SIZE;
	x.chromosome[idx] = rand() % 18;
}

// inicializa e retorna uma populacao, onde todos os membros dela estao com o estado do cubo de origem em seus estados
vector<Individual> initPop(Individual origin) {
	vector<Individual> population(POPULATION_SIZE);

	for (int i = 0; i < population.size(); i++) {
		copy(&origin.state[0][0][0], &origin.state[0][0][0] + 3 * 3 * 6, &population[i].state[0][0][0]); // coloca o estado do cubo de origem em todo mundo
		
		// inicializa movimentos aleatorios
		for (int j = 0; j < CHROMOSOME_SIZE; j++) {
			population[i].chromosome[j] = rand() % 18;
		}

		apply_movements(population[i]);

		calculate_fitness(population[i]);
	}
	// ordena pelo fitness em ordem decrescente
	sort(population.begin(), population.end(), cmp);

	return population;
}

int main() {
	srand(time(NULL)); // inicializa a semente do gerador de numeros aleatorios

	// le o cubo de entrada
	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 3; j++) {
			for (int k = 0; k < 3; k++) {
				char tmp;
				scanf(" %c", &tmp);

				switch (tmp) {
					case 'W':
						origin.state[i][j][k] = 0;
						break;
					case 'Y':
						origin.state[i][j][k] = 1;
						break;
					case 'G':
						origin.state[i][j][k] = 2;
						break;
					case 'B':
						origin.state[i][j][k] = 3;
						break;
					case 'O':
						origin.state[i][j][k] = 4;
						break;
					case 'R':
						origin.state[i][j][k] = 5;
						break;
				}
			}
		}
	}

	// inicializa a primeira populacao de todas
	vector<Individual> population = initPop(origin);

	// exibe informacoes sobre essa primeira populacao
	printf("Initial population\n");
	print_population_info(population);

	// comeca o algoritmo genetico, a repeticao para ao atingir o numero maximo de geracoes ou ao completar o cubo
	int generation = 0;
	while (generation < MAX_GENERATIONS && population[0].fitness != 48) {
		// genocidio
		if (generation != 0 && generation % GENOCIDE_GENS == 0) {
			cout << "GENOCIDE" << endl << endl;
			all_moves.insert(all_moves.end(), &population[0].chromosome[0], &population[0].chromosome[0] + CHROMOSOME_SIZE); // guarda os movimentos do melhor
			copy(&population[0].state[0][0][0], &population[0].state[0][0][0] + 6 * 3 * 3, &origin.state[0][0][0]); // copia o cubo do melhor para o cubo de origem
			population.clear(); // mata todo mundo
			population = initPop(origin); // cria uma nova populacao, que agora visa melhorar o novo cubo de origem
		}

		printf("Generation %d\n", generation);

		// pool represeenta a populacao que sera a nova geracao
		vector<Individual> pool(population); // inicialmente, pool e uma copia da populacao
		for (int i = 0; i < pool.size(); i++) {
			mutate(pool[i]); // muta todos os elementos de pool
			copy(&origin.state[0][0][0], &origin.state[0][0][0] + 3 * 3 * 6, &pool[i].state[0][0][0]); // copia o cubo de origem para todos de pool
			apply_movements(pool[i]); // aplica os movimentos
			calculate_fitness(pool[i]); // calcula o fitness

			// como nos alteramos um movimento na mutacao, o estado atual do cubo e a o seu valor de fitness se tornam invalidos, por isso precisamos copiar
			// da origem, aplicar os movimentos e calcular o fitness de novo
		}

		// elitismo
		for (int i = 0; i < population.size() * ELITISM_RATE; i++) {
			pool.push_back(population[i]);
		}

		// ordena pelo fitness em ordem decrescente
		sort(pool.begin(), pool.end(), cmp);

		// trunca a populacao para seu tamanho correto (ela esta maior do que o tamanho correto por causa do elitismo)
		pool.resize(POPULATION_SIZE);

		// predacao
		if (generation != 0 && generation % PREDATION_GENS == 0) {
			cout << "PREDATION" << endl << endl;
			pool.resize(POPULATION_SIZE * (1.0 - PREDATION_RATE)); // mata os piores 20% da populacao
			vector<Individual> tmp = initPop(origin); // cria uma nova populacao cheia de individuos aleatorios
			tmp.resize(POPULATION_SIZE * PREDATION_RATE); // trunca essa populacao para conter apenas 20% dos seus membros 
			pool.insert(pool.end(), tmp.begin(), tmp.end()); // coloca os novos 20% na pool
			sort(pool.begin(), pool.end(), cmp); // ordena novamente
			pool.resize(POPULATION_SIZE); // trunca pra evitar erros de arredondamento, vai que pool agora tem POPULATION_SIZE + 1 individuos, ne
		}

		// exibe informacoes sobre a populacao da proxima geracao
		print_population_info(pool);

		// troca a populacao com pool, passa para a proxima geracao
		population.swap(pool);
		generation++;
	}

	// acabou o algoritmo genetico
	printf("----------------------------------------------------------------------\n\n");
	print_individal(population[0]); // esse e o melhor individuo

	// inserimos os movimentos dele no final do all_moves
	all_moves.insert(all_moves.end(), &population[0].chromosome[0], &population[0].chromosome[0] + CHROMOSOME_SIZE);
	print_moves(all_moves); // exibe todos os movimentos necessarios para ir do cubo de entrada do programa ate o cubo mostrado

	return 0;
}